# Timetable-Generator

A GUI through which timetables can be automatically generated.
