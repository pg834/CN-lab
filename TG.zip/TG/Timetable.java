import java.util.*; 
@SuppressWarnings("unused")
public class Timetable{
    private String name;
    String a[][] = new String[5][6];  
    void setName(String s){
        this.name=s;
    } 
    String getName(){
        return this.name;
    }
}