import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHandler {
    private Connection connection;

    public DatabaseHandler() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/timetable_generator", "username", "password");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createBatchTable() {
        String sql = "CREATE TABLE IF NOT EXISTS batch (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255))";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertBatch(String name) {
        String sql = "INSERT INTO batch (name) VALUES (?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<String> getBatches() {
        List<String> batches = new ArrayList<>();
        String sql = "SELECT name FROM batch";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                batches.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return batches;
    }

    // Add similar methods for courses and professors

    public void close() {
        try {
            if (connection!= null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}